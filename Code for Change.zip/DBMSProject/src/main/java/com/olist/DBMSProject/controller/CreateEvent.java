package com.olist.DBMSProject.controller;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.olist.DBMSProject.model.Events;
import com.olist.DBMSProject.model.Users;
import com.olist.DBMSProject.model.orderstatus;
import com.olist.DBMSProject.service.DashBoardRepository;
import com.olist.DBMSProject.service.EventRepository;
import com.olist.DBMSProject.service.UserRepository;

@Controller
public class CreateEvent {
    @Autowired
    private EventRepository repository;

    private List<Users> user= new ArrayList<>();

 
    
    @RequestMapping(value="NewEvent")
    public void dashboard(HttpServletRequest request) throws ParseException {
    	Events e=new Events();
    	if(request.getParameter("id")!=null)
    	//ModelAndView mav = new ModelAndView("NewEvent");
    	{	e.setEVENT_DESC(request.getParameter("desc"));
    	e.setEVENT_ID(request.getParameter("id"));
    	e.setEVENT_LOCATION(request.getParameter("location"));
    	e.setEVENT_NAME(request.getParameter("name"));
    	final String OLD_FORMAT = "yyyy-MM-dd";
    	final String NEW_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
    	String oldDateString = request.getParameter("date");
    	String newDateString;

    	DateFormat formatter = new SimpleDateFormat(OLD_FORMAT);
    	java.util.Date d =  formatter.parse(oldDateString);
    	((SimpleDateFormat) formatter).applyPattern(NEW_FORMAT);
    	newDateString = formatter.format(d);
    	System.out.println(newDateString);

    	Timestamp ts = Timestamp.valueOf(newDateString);
    	System.out.println(ts);
    	e.setEVENT_TIME(ts);
    	
    	 repository.createevent(e);
    	// List<Events> e=repository.showallevents();
    	 //System.out.println(l);
    	// mav.addObject("noorder", l);
         //mav.addObject("events", e);

//         System.out.println(l+"jyotik");
        // List<orderstatus> orders=repository.showorderstatus();
         //float a=repository.showrepeatrate();
       //  double b = 4.2;
        // for(int i=1;i<orders.size();i++) {
        	 
        //	 System.out.println(orders.get(i).getOrders()+"  "+orders.get(i).getStatus());
        // }
        // mav.addObject("orderstatus", orders);
       //  mav.addObject("repeatrate",a);
        // mav.addObject("reviewScore", b);
    	 
      
    }
    }

}
