google.charts.load('current', {'packages':['table']});
google.charts.setOnLoadCallback(drawTable);

var SellersDelay_Id = new Array();
var SellersDelay_para = new Array();
var SellersDelay_venue=new Array();
var SellersDelay_desc=new Array();
var SellerDelay_time=new Array();
var countSellerDelay = 0;




function drawTable() 
{
  var data = new google.visualization.DataTable();
  data.addColumn('string', 'Event_name');
  data.addColumn('string', 'Event_Date');
  data.addColumn('string','Event Venue');
  data.addColumn('string','Event Description');
  data.addColumn('string','Time')

  var i = 0;
  var t=false;
  for(i = 0; i < countSellerDelay; i++)
  {
    data.addRows([
      [SellersDelay_Id[i], SellersDelay_para[i],SellersDelay_venue[i],SellersDelay_desc[i],SellerDelay_time[i]]
      ]);
  }


  var table = new google.visualization.Table(document.getElementById('table_div'));

  table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
  google.visualization.events.addListener(table, 'select', function() {
	    var row = table.getSelection()[0].row;
	    document.getElementById('info').innerHTML=data.getValue(row, 0);
	    var para = document.createElement("p");
	    var node = document.createTextNode(data.getValue(row, 1));
	    para.appendChild(node);
	    var para1 = document.createElement("p");
	    var node1 = document.createTextNode(data.getValue(row, 2));
	    para1.appendChild(node1);
	    var para2 = document.createElement("p");
	    var node2 = document.createTextNode(data.getValue(row, 3));
	    para2.appendChild(node2);
        var para3= document.createElement("button");
        para3.innerHTML="Update";
        var att = document.createAttribute("onclick");   
          
// Create a "class" attribute
        att.value ="UpdateEvent()" ;
        para3.setAttributeNode(att);  


	    var element = document.getElementById("info");
	    element.appendChild(para);
	    element.appendChild(para1);
	    element.appendChild(para2);
	    element.appendChild(para3);
	   // alert('You selected ' + data.getValue(row, 0));
	  });
}

function UpdateEvent(){
	location.replace("http://localhost:8080/UpdateEvent");

}




