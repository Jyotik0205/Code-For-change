package com.olist.DBMSProject.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.olist.DBMSProject.model.Events;
import com.olist.DBMSProject.model.Users;
import com.olist.DBMSProject.model.orderstatus;

@Repository
public class EventRepository {
	
	
	@Autowired
	JdbcTemplate jdbcTemplate;

		public int showtotaleventrepo() {
			String sql="select count(*) from SLAMBA.sf_events";
			 int numOfCars = jdbcTemplate.queryForObject(sql, Integer.class);

			return numOfCars;
		}
		
		public List<Events> showallevents() 
		{
			
			String sql="select * from SLAMBA.sf_events";
			return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Events.class));
		}
		
		public void createevent(Events e) 
		{
			
			
			String sql="insert into SLAMBA.sf_events(event_id, event_name, event_time,event_location,event_desc) VALUES(?,?,?,?,?)";
		 jdbcTemplate.update(sql, e.getEVENT_ID(), e.getEVENT_NAME(), e.getEVENT_TIME(),e.getEVENT_LOCATION(),e.getEVENT_DESC());
		}
		public List<Events> search(String s){
			String sql="select * from SLAMBA.sf_events where event_id="+s;
			return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Events.class));
			
		}

public float showrepeatrate() {
	
	String sql="SELECT a.repeat/b.total * 100 AS repeatrate FROM" + 
			"    (" + 
			"        SELECT" + 
			"            COUNT(*) AS repeat" + 
			"        FROM" + 
			"            (" + 
			"                SELECT" + 
			"                    *" + 
			"                FROM" + 
			"                    (" + 
			"                        SELECT" + 
			"                            customer_unique_id," + 
			"                            COUNT(*) AS count" + 
			"                        FROM" + 
			"                            jyotik.olist_customer_order" + 
			"                        GROUP BY" + 
			"                            customer_unique_id" + 
			"                    )" + 
			"                ORDER BY" + 
			"                    count DESC" + 
			"            )" + 
			"        WHERE" + 
			"            count > 1" + 
			"    ) a, " + 
			"    (" + 
			"        SELECT" + 
			"            COUNT(*) AS total" + 
			"        FROM" + 
			"            (" + 
			"                SELECT" + 
			"                    *" + 
			"                FROM" + 
			"                    (" + 
			"                        SELECT" + 
			"                            customer_unique_id," + 
			"                            COUNT(*) AS count" + 
			"                        FROM" + 
			"                            jyotik.olist_customer_order" + 
			"                        GROUP BY" + 
			"                            customer_unique_id" + 
			"                    )" + 
			"                ORDER BY" + 
			"                    count DESC" + 
			"            )" + 
			"    ) b" ;
	
	return jdbcTemplate.queryForObject(sql, Float.class);

			
}

}
