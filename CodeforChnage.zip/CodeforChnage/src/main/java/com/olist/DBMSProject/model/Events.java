package com.olist.DBMSProject.model;

import java.sql.Blob;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Events {
	@Id
	@GeneratedValue
	public String EVENT_ID;
	public String getEVENT_ID() {
		return EVENT_ID;
	}


	public void setEVENT_ID(String eVENT_ID) {
		EVENT_ID = eVENT_ID;
	}


	public String getEVENT_NAME() {
		return EVENT_NAME;
	}


	public void setEVENT_NAME(String eVENT_NAME) {
		EVENT_NAME = eVENT_NAME;
	}


	public Timestamp getEVENT_TIME() {
		return EVENT_TIME;
	}


	public void setEVENT_TIME(Timestamp eVENT_TIME) {
		EVENT_TIME = eVENT_TIME;
	}


	public String getEVENT_LOCATION() {
		return EVENT_LOCATION;
	}


	public void setEVENT_LOCATION(String eVENT_LOCATION) {
		EVENT_LOCATION = eVENT_LOCATION;
	}


	public String getEVENT_DESC() {
		return EVENT_DESC;
	}


	public void setEVENT_DESC(String eVENT_DESC) {
		EVENT_DESC = eVENT_DESC;
	}


	public Blob getEVENT_IMAGE() {
		return EVENT_IMAGE;
	}


	public void setEVENT_IMAGE(Blob eVENT_IMAGE) {
		EVENT_IMAGE = eVENT_IMAGE;
	}


	public String getLat() {
		return lat;
	}


	public void setLat(String lat) {
		this.lat = lat;
	}


	public String EVENT_NAME;
	public Timestamp EVENT_TIME;
	public String EVENT_LOCATION;
	public String EVENT_DESC;
	public Blob EVENT_IMAGE;
	public String lat;
	

	public Events() {}

	
}